stored, not deflated
